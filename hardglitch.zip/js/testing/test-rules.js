// This file contain just rules for testing.

export { test_rules }

import * as concepts from "../core/concepts.js";
import { sprite_defs } from "../game-assets.js";
import { destroy_at } from "../rules/destruction.js";
import * as visibility from "../core/visibility.js";


const test_rules = [
];

