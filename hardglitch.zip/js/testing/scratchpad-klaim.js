// This is where Klaim test some ideas.

import * as concepts from "../core/concepts.js";



level = {
    floor_tiles : [],
    surface_tiles : [],
    items : [],
    characters: [],
    player_entry_position = { x: 5, y: 5 },
    exit_position = { x: 20, y: 20 },
};


