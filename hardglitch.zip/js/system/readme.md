This directory will only contain the code for the systems
necessary to display, hear handle input of the game.
Avoid game-specific code here, if you can. ^^
If you are not sure, start by adding code somewhere in the files in the
js/ directory, we'll probably move reused code where it needs to be, no problem.

